#include <signal.h>
#include <unistd.h>

int main() {
    while(1) pause();
    return 0;
}